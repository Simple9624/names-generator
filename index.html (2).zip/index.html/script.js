
const nameContainer = document.getElementById("name-container");
const generateButton = document.getElementById("generate-button");

const names = ["Alice", "Bob", "Charlie", "David", "Emily", "Frank", "Grace", "Henry", "Isabella", "Jack", "Kate", "Liam", "Mia", "Nathan", "Olivia", "Penelope", "Quinn", "Riley", "Sophia", "Thomas", "Uma", "Victoria", "William", "Xander", "Yara", "Zoe"];

function generateName() {
  for (let i = 0; i < 100; i++) {
    const randomIndex = Math.floor(Math.random() * names.length);
    const generatedName = names[randomIndex];
    const nameElement = document.createElement("p");
    nameElement.textContent = generatedName;
    nameContainer.appendChild(nameElement);
  }
}

if (generateButton) {
  generateButton.onclick = generateName;
}



function generateName() {
	var category = document.querySelector('input[name="category"]:checked').value;
	var name = '';
	
	if (category === 'female') {
		var femaleNames = [
			'Ava',
			'Chloe',
			'Emma',
			'Isabella',
			'Mia',
			'Olivia',
			'Sophia'
		];
		
		name = femaleNames[Math.floor(Math.random() * femaleNames.length)];
	}
	
	if (category === 'male') {
		var maleNames = [
			'Aiden',
			'Ethan',
			'Jackson',
			'Jacob',
			'Jayden',
			'Noah',
			'William'
		];
		
		name = maleNames[Math.floor(Math.random() * maleNames.length)];
	}
	
	if (category === 'business') {
		var businessNames = [
			'Acme Corporation',
			'Globex Corporation',
			'Initech',
			'Oscorp Industries',
			'Stark Industries',
			'Wayne Enterprises'
		];
		
		name = businessNames[Math.floor(Math.random() * businessNames.length)];
	}
	
	document.getElementById('name').innerHTML = name;
}

// password generator

function generatePassword() {
	// define character sets
	const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
	const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	const numbers = '0123456789';
	const symbols = '!@#$%^&*()_+-={}[]|:;"<>,.?/';
  
	// define password length and character set to use
	const passwordLength = 10;
	const characterSet = lowercaseLetters + uppercaseLetters + numbers + symbols;
  
	let password = '';
  
	// generate random password
	for (let i = 0; i < passwordLength; i++) {
	  const randomIndex = Math.floor(Math.random() * characterSet.length);
	  password += characterSet[randomIndex];
	}
  
	// display generated password in input field
	const passwordInput = document.getElementById('password');
	passwordInput.value = password;
  }
  

//   baby name generator
const boyNames = ['Liam', 'Noah', 'Ethan', 'Oliver', 'Aiden', 'Caleb', 'Lucas', 'Mason', 'Elijah', 'Logan', 'Jackson', 'Jacob', 'Owen', 'Levi', 'Benjamin', 'William', 'James', 'Alexander', 'Sebastian', 'Michael'];
const girlNames = ['Emma', 'Olivia', 'Ava', 'Sophia', 'Isabella', 'Mia', 'Charlotte', 'Amelia', 'Evelyn', 'Abigail', 'Harper', 'Emily', 'Elizabeth', 'Avery', 'Sofia', 'Ella', 'Madison', 'Scarlett', 'Victoria', 'Chloe'];

function generateBabyName() {
  const gender = Math.floor(Math.random() * 2); // 0 = boy, 1 = girl
  const names = gender === 0 ? boyNames : girlNames;
  const randomIndex = Math.floor(Math.random() * names.length);
  const babyName = names[randomIndex];
  document.getElementById('baby-name').textContent = babyName;
}

// pet name generator
// Define arrays of pet names
const cuteNames = ["Buddy", "Daisy", "Rosie", "Lola", "Bailey", "Charlie", "Sadie", "Max", "Molly", "Lucy"];
const funnyNames = ["Sir Barks-a-Lot", "Bartholomew Wigglebottom", "Professor Fuzzybottom", "Captain Snuggles", "Fido McFluffernutter", "Sir Poops-a-Lot", "Count Drool-a-Lot", "Duke Puddlesworth", "Baron von Cuddlesworth", "Lord Purrington"];
const coolNames = ["Jax", "Maverick", "Diesel", "Ace", "Gunner", "Harley", "Ryder", "Ziggy", "Jagger", "Bear"];

// Get references to HTML elements
const nameTypeSelect = document.getElementById("nameType");
const generateBtn = document.getElementById("generateBtn");
const generatedName = document.getElementById("generatedName");

// Define function to generate pet name
function generatePetName() {
// Get selected name type
const nameType = nameTypeSelect.value;

// Generate random name based on selected name type
let name;
if (nameType === "cute") {
name = cuteNames[Math.floor(Math.random() * cuteNames.length)];
} else if (nameType === "funny") {
name = funnyNames[Math.floor(Math.random() * funnyNames.length)];
} else if (nameType === "cool") {
name = coolNames[Math.floor(Math.random() * coolNames.length)];
}

// Update generated name in HTML
generatedName.textContent = name;
}

// Define event listener for button click
generateBtn.addEventListener("click", generatePetName);

// wordpress rest api
fetch('https://your-wordpress-site.com/wp-json/wp/v2/posts')
  .then(response => response.json())
  .then(data => {
    // Parse the data and display it on your script site
    const postsContainer = document.querySelector('#posts-container');
    data.forEach(post => {
      const postDiv = document.createElement('div');
      const postTitle = document.createElement('h2');
      const postContent = document.createElement('div');
      postTitle.textContent = post.title.rendered;
      postContent.innerHTML = post.content.rendered;
      postDiv.appendChild(postTitle);
      postDiv.appendChild(postContent);
      postsContainer.appendChild(postDiv);
    });
  });
