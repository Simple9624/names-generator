
const nameContainer = document.getElementById("name-container");
const generateButton = document.getElementById("generate-button");

const names = ["Alice", "Bob", "Charlie", "David", "Emily", "Frank", "Grace", "Henry", "Isabella", "Jack", "Kate", "Liam", "Mia", "Nathan", "Olivia", "Penelope", "Quinn", "Riley", "Sophia", "Thomas", "Uma", "Victoria", "William", "Xander", "Yara", "Zoe"];

function generateName() {
  for (let i = 0; i < 100; i++) {
    const randomIndex = Math.floor(Math.random() * names.length);
    const generatedName = names[randomIndex];
    const nameElement = document.createElement("p");
    nameElement.textContent = generatedName;
    nameContainer.appendChild(nameElement);
  }
}

if (generateButton) {
  generateButton.onclick = generateName;
}



function generateName() {
	var category = document.querySelector('input[name="category"]:checked').value;
	var name = '';
	
	if (category === 'female') {
		var femaleNames = [
			'Ava',
			'Chloe',
			'Emma',
			'Isabella',
			'Mia',
			'Olivia',
			'Sophia'
		];
		
		name = femaleNames[Math.floor(Math.random() * femaleNames.length)];
	}
	
	if (category === 'male') {
		var maleNames = [
			'Aiden',
			'Ethan',
			'Jackson',
			'Jacob',
			'Jayden',
			'Noah',
			'William'
		];
		
		name = maleNames[Math.floor(Math.random() * maleNames.length)];
	}
	
	if (category === 'business') {
		var businessNames = [
			'Acme Corporation',
			'Globex Corporation',
			'Initech',
			'Oscorp Industries',
			'Stark Industries',
			'Wayne Enterprises'
		];
		
		name = businessNames[Math.floor(Math.random() * businessNames.length)];
	}
	
	document.getElementById('name').innerHTML = name;
}

// password generator

function generatePassword() {
	// define character sets
	const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
	const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	const numbers = '0123456789';
	const symbols = '!@#$%^&*()_+-={}[]|:;"<>,.?/';
  
	// define password length and character set to use
	const passwordLength = 10;
	const characterSet = lowercaseLetters + uppercaseLetters + numbers + symbols;
  
	let password = '';
  
	// generate random password
	for (let i = 0; i < passwordLength; i++) {
	  const randomIndex = Math.floor(Math.random() * characterSet.length);
	  password += characterSet[randomIndex];
	}
  
	// display generated password in input field
	const passwordInput = document.getElementById('password');
	passwordInput.value = password;
  }
  
